""" pandas utiltities

"""
from __future__ import annotations

import io

import pandas as pd

__all__ = [
        'get_df_info',
        ]


def get_df_info(
        df: pd.DataFrame,
        verbose = None, 
        max_cols: int|None = None, 
        memory_usage: bool | None = None, 
        show_counts: bool | None = None,
        indent: str = '',
        ) -> str:
    """ Returns a string with the output of `df.info()`

    Parameters
    ----------
    df: frame
        Any data frame

    verbose: bool, optional
        Whether to print the full summary. By default, the setting in
        pandas.options.display.max_info_columns is followed.

    indent: str, optional
        If given, indent every line in the output

    max_cols: int, optional
        When to switch from the verbose to the truncated output. If the
        DataFrame has more than max_cols columns, the truncated output is
        used. By default, the setting in
        pandas.options.display.max_info_columns is used.

    memory_usage: bool, str, optional
        Specifies whether total memory usage of the DataFrame elements
        (including the index) should be displayed. By default, this follows
        the pandas.options.display.memory_usage setting.

        True always show memory usage. False never shows memory usage. A value
        of ‘deep’ is equivalent to “True with deep introspection”. Memory
        usage is shown in human-readable units (base-2 representation).
        Without deep introspection a memory estimation is made based in column
        dtype and number of rows assuming values consume the same memory
        amount for corresponding dtypes. With deep memory introspection, a
        real memory usage calculation is performed at the cost of
        computational resources. See the Frequently Asked Questions for more
        details.

    show_counts: bool, optional
        Whether to show the non-null counts. By default, this is shown only if
        the DataFrame is smaller than pandas.options.display.max_info_rows and
        pandas.options.display.max_info_columns. A value of True always shows
        the counts, and False never shows the counts.

    Returns
    -------
    str:
        A string with the output of df.info()
    """
    buf = io.StringIO()
    df.info(buf=buf, verbose=verbose, max_cols=max_cols,
            memory_usage=memory_usage, show_counts=show_counts)
    out = buf.getvalue()
    if len(indent) > 0:
        out = '\n'.join(f"{indent}{x}" for x in out.splitlines())
    return out

