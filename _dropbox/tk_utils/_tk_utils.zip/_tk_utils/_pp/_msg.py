""" Message utilities

         
"""
from __future__ import annotations

import re

from ._colorize import colorize
from .. import (
        opts,
        decorators,
        )

__all__  = [
        'MsgLines',
        'fmt_msg',
        'ask_yes',
        ]

RQUOTES = re.compile(r'''("|')''')
cfg = opts.cfg

def ask_yes(
        msg: str|None = None, 
        color: str = None,
        strict: bool = True,
        default_yes: bool = False,
        prompt: str | None = None,
        ):
    """ Asks for user confirmation and returns True if confirmed.
    Answers are NOT case-sensitive

    Parameters
    ----------
    msg: str, optional
        Message to display before asking user to confirm.

    color: str, optional
        Message color

    strict: bool, default True
        If True, disable shortcuts y=Yes and n=No

    default_yes: bool, default False
        Pressing <ENTER> means YES

    prompt: str, optional
        Prompt message. Defaults to "Press YES to continue, NO to exit"
        
    """
    if default_yes is False:
        if prompt is None:
            prompt = f'Please type YES to continue or NO to exit: '
        try_again = "You must type YES or NO"
    else:
        if prompt is None:
            prompt = f"Press [ENTER] to continue, or type NO to exit: "
        try_again = "You must either press [ENTER] or type YES/NO"

    if msg is not None:
        msg = f"{msg}\n{prompt}"
    else:
        msg = prompt

    # Decide valid answers
    yes = {'yes'}
    no = {'no'}

    if strict is False:
        yes.add('y')
        no.add('n')

    valid = yes | no

    if color is not None:
        msg = colorize(msg, color=color)

    answer = input(msg)
    chk_answer = RQUOTES.sub('', answer.lower().strip())
    try_again = f"{try_again}, not '{answer}'. Try again: "

    if len(chk_answer) == 0: 
        if default_yes:
            return True
        else:
            return ask_yes(prompt=try_again, strict=strict,
                           default_yes=default_yes)
    elif chk_answer not in valid:
        return ask_yes(prompt=try_again, strict=strict,
                       default_yes=default_yes)
    elif chk_answer in yes:
        return True
    else:
        return False


class MsgLines(list):
    """ List subclass representing message lines
    """

    def add(
            self, 
            line: str,
            sep: bool = False,
            strip: bool = False,
            newline: bool = False,
            bold: bool = False,
            color: str|None = None,
            indent: str = '',
            index: int|None = None,
            ):
        """  Adds a line to the message

        Parameters
        ----------
        line : str
            The line to add

        sep : bool, default False
            If True, insert separators

        strip : bool, default False
            If True, strip the line first

        newline : bool, default False
            If True, add a newline char after the (stripped) line

        bold : bool, default False
            If True, line (and separators) will be printed in bold

        index : int, optional
            If None, append the element to the end of the list, 
            otherwise, insert 

        indent: str, default ''
            If given, add indentation to this line.
            If strip is True, indentation will be added after stripping

        Examples
        --------
        >>> import tk_utils
        >>> tk_utils.cfg.pp.min_sep_width = 5
        >>> msg = tk_utils.pp.MsgLines([0, 1, 4])
        >>> msg.add('a', sep=True, index=2)
        >>> print(msg)
        [0, 1, '-----', 'a', '-----', 4]

        """
        new = [line if strip is False else line.strip()]
        if sep is True:
            _sep = '-' * max(len(line), opts.cfg.pp.min_sep_width)
            new = [_sep] + new + [_sep]
        if newline is True:
            new.append('')
        if color is not None:
            new = [colorize(x, color) for x in new]
        if bold is True:
            #   [ANSI escape codes](https://en.wikipedia.org/wiki/ANSI_escape_code)
            new = [f"\033[1m{x}\033[0m" for x in new]

        if len(indent) > 0:
            new = [f"{indent}{x}" for x in new]

        if index is None:
            self.extend(new)
        else:
            for i, ele in enumerate(new):
                self.insert(index+i, ele)


    def print(self, quiet: bool = False):
        """ Prints the current message (list of strings)
        """
        if quiet is False:
            print('\n'.join(self))


def _msg_as_hdr(
        msg: str | list, 
        min_sep_len: int | None = None,
        max_sep_len: int | None = None, 
        sep: str = '-'):
    """ Returns a list with the message enclosed in separator lines

    Parameters
    ----------
    """
    if min_sep_len is None:
        min_sep_len = cfg.pp.min_sep_width
    if max_sep_len is None:
        max_sep_len = cfg.pp.max_sep_width

    if isinstance(msg, str):
        msg = [msg]
    sep_len = min(max_sep_len, max(min_sep_len, max(len(x) for x in msg)))
    line = sep*sep_len
    return [line] + msg + [line]


# TODO: Finish description of parms
def fmt_msg(
        msg, 
        color: str | None = None, 
        indent: str = '',
        as_hdr: bool = False,
        min_sep_len: int | None = None,
        max_sep_len: int | None = None, 
        ):
    """ Returns a formatted message to print

    Parameters
    ----------
    msg : list, str
        Message to be formatted. If list, return a '\n'-joined string

    color : str, optional

    indent : str
        The string to prefix/indent every line in the message
        Defaults to ''

    as_hdr: bool, optional
        If True, enclose message in separator lines



    Examples
    --------
    >>> import tk_utils
    >>> msg = 'This is a msg'
    >>> print(tk_utils.pp.fmt_msg(msg, as_hdr=True))
    ----------------------------------------
    This is a msg
    ----------------------------------------

    """
    if indent is None:
        indent = ''
    if as_hdr is True:
        msg = _msg_as_hdr(msg, min_sep_len=min_sep_len, max_sep_len=max_sep_len)
    if isinstance(msg, (tuple, list)):
        msg = '\n'.join([f'{indent}{x}' for x in msg])
    else:
        msg = f'{indent}{msg}'
    if color is not None:
        return colorize(msg, color=color)
    else:
        return msg



