""" benchmark.py

This module provides a simple wrapper around the timeit and tracealloc modules
to provide execution time and estimates of memory consumption.


"""
# TODO: Finish this, not complete
from __future__ import annotations

import dataclasses as dc
import contextlib
import datetime as dt
import inspect
import io
import os
import timeit
import tracemalloc

from . import (
        opts,
        decorators,
        _utils,
        _pp,
        )


BENCH_PARMS = {
    'stmt': """
    stmt: str, optional
        String with the statements to be executed.  The statements may contain
        newlines, as long as they don't contain multi-line string literals.
    """,
    #'func': """
    #func: Callable, optional
    #    Cannot be used with `stmt`. Function to benchmark.
    #""",
    #'func_kargs': """
    #func_kargs: dict, optional
    #    Cannot be used with `stmt`. Dictionary with parms to pass to `func`.
    #""",
    'setup': """
    setup: str, optional
        String with statements to be executed once initially. Execution time
        of these statements will not be timed. These are typically import
        statements. Not required if user set parameter `global` to `globals()`
        Default to 'pass'
    """,
    'repeat': """
    repeat: int, optional
        Number of times the timer will time the execution of the codes. The
        final execution time will be the minimum time across all repeats.
        Defaults to 3.
    """,
    'number': """
    number: int, optional
        Number of times the statements in `stmt` or the function `func` will
        be executed. Defaults to 100.
    """,
    'globals': """
    globals: dict, optional
        Dictionary with namespace (typically `globals()`) If 'globals' is
        specified, the code will be executed within that namespace (as opposed
        to inside timeit's namespace).
    """,
    
    }



@decorators.doc(indent=1, parms=BENCH_PARMS)
@dc.dataclass(kw_only=True)
class BenchmarkOpts(opts.BaseOpts):
    """ Dataclass with benchmarking options

    Parameters
    ----------
    {stmt}
    {setup}
    {repeat}
    {number}
    {globals}

    """
    stmt: str | None
    #func: Callable | None
    #func_kargs: dict | None
    setup: str | None
    repeat: int
    number: int
    globals: dict | None

    def __post_init__(self):

        if self.setup is None:
            self.setup = 'pass'
        #self._chk_parms()

    #def _chk_parms(self):
    #    """
    #    """
    #    if self.stmt is not None and self.func is not None:
    #        err = f"Parms `stmt` and `func` are mutually exclusive"
    #        raise ValueError(err)
    #    elif self.stmt is None and self.func is None:
    #        err = f"One of `stmt` and `func` must not be None"
    #        raise ValueError(err)
    #    # Ensure func is callable
    #    if self.func is not None and not callable(self.func):
    #        err = f"Parm `func` must be a callable, not {type(self.func)}"
    #        raise ValueError(err)



@decorators.doc(indent=1, parms=BENCH_PARMS)
class Benchmark:
    """ Benchmarking util

    Parameters
    ----------
    {stmt}
    {setup}
    {repeat}
    {number}
    {globals}

    """


    def __init__(
            self,
            stmt: str | None = None,
            #func: Callable | None = None,
            #func_kargs: dict | None = None,
            setup: str | None = None,
            repeat: int = 3,
            number: int = 100,
            globals: dict | None = None,
            ):

        self.opts = BenchmarkOpts(
                stmt=stmt,
                #func=func,
                #func_kargs=func_kargs,
                setup=setup,
                repeat=repeat,
                number=number,
                globals=globals,
                )

        self.msg_opts = {
                'sep': True,
                }
        self.indent = '  '


    def _msg_lst(self, s):
        """ Returns the string as a list of formatted commands
        """
        return [f'{self.indent}>>> {x}' for x in s.splitlines() if x.strip() != '']


    def mk_start_msg(
            self,
            start_msg: str,
            show_stmt: bool,
            show_setup: bool,
            ) -> str:
        """ Returns the starting message 
        """
        if isinstance(start_msg, str):
            msg = [start_msg]
        else:
            msg = start_msg
        if show_stmt:
            stmt_msg = self._msg_lst(self.opts.stmt)
            msg.extend([''] + stmt_msg)
        if show_setup:
            setup_msg = ['', 'Setup:'] + self._msg_lst(self.opts.setup)
            msg.extend(setup_msg)
        return _pp.fmt_msg(msg, as_hdr=True)




    def benchmark(
            self,
            start_msg: str | None = None,
            show_stmt: bool = True,
            show_setup: bool = True,
            quiet: bool = False,
            ):
        """

        Parameters
        ----------
        quiet: bool, default False
            If True, ignore any output from statements

        """
        repeat, number = self.opts.repeat, self.opts.number
        stdout = io.StringIO()

        if start_msg is None:
            start_msg = ['Running benchmark for statements:']
            if repeat > 1:
                start_msg.append(
                        f"  Running {repeat} batches of {number} calls")
            else:
                start_msg.append(f"  Running {number} calls")

        print(self.mk_start_msg(
            start_msg=start_msg, 
            show_stmt=show_stmt,
            show_setup=show_setup,
            ))



        #   Better to use the Timer class than the `timeit.repeat` method
        t = timeit.Timer(
                        stmt=self.opts.stmt,
                        setup=self.opts.setup,
                        globals=self.opts.globals
                        )

        # Call timeit once so it creates all necessary objects (which takes a lot
        # of memory). This will help with the reliability of the memory stats 
        if number > 1:
            with contextlib.redirect_stdout(stdout):
                t.timeit(number=1)


        # Start mem trace...
        tracemalloc.start()

        if quiet is True:
            with contextlib.redirect_stdout(stdout):
                times = t.repeat(repeat=repeat, number=number)
        else:
            times = t.repeat(repeat=repeat, number=number)

        # Keep the best time
        secs = min(times)
        elapsed = _utils.fmt_elapsed(dt.timedelta(seconds=secs))

        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        mem = _utils.bytes2human(peak)

        # Results

        msg = [
        f"Results:",
        f'{self.indent}Best time: {elapsed}',
        f'{self.indent}Memory peak: {mem}',
        '',
        ]
        print(_pp.fmt_msg(msg, as_hdr=False))




@decorators.doc(indent=1, parms=BENCH_PARMS)
def bench_func(
        func: Callable,
        number: int = 100,
        repeat: int = 1,
        setup: str | list[str] | None = None,
        quiet: bool = True,
        ):
    """ Benchmarks a function 

    Parameters
    ----------
    func: Callable
        The function to benchmark. This function must not take any parameters
        or all parameters must have a default value.
        

    {number}
    {repeat}
    setup: str, list[str],  optional
        String or list of strings with statements to be executed once
        initially.


    Examples
    --------

    """
    if not callable(func):
        err = f"Parm `func` must be a callable"

    func_name = func.__name__

    show_setup = True
    if setup is None:
        setup = f'from __main__ import {func_name}'
        show_setup = False
    elif isinstance(setup, (list, tuple)):
        setup = '\n'.join(setup)


    # TODO: Implement this
    # Check if all parameters have default values
    #sig = inspect.signature(func)


    if repeat > 1:
        count_msg = f"Best of {repeat} batches of {number} calls"
    else:
        count_msg = f"Function will be called {number} times"
    if quiet is True:
        sup_msg = f"STDOUT redirected during function calls"
    else:
        sup_msg = None


    start_msg = [
            f"Benchmarking function `{func_name}():`",
            f" - {count_msg}",
            ]
    if sup_msg is not None:
        start_msg.append(f" - {sup_msg}")


    b = Benchmark(
            stmt=f"{func_name}()",
            setup=setup,
            number=number,
            repeat=repeat,
            )
    b.benchmark(
            start_msg=start_msg,
            show_stmt=False,
            show_setup=show_setup,
            quiet=quiet,
            )


def benchmark(stmt, setup='pass', repeat=3, number=100, globals=None,
        verbose=False):
    """ Wrapper around `timeit` and `tracealloc` to produce execution time
    and memory allocation for Python statements. It will print out a message
    with the total execution time and the peak memory allocation.

    The peak memory allocation does not represent the actual memory consumed
    by the statements due to overhead created by `timeit` and `tracemalloc`.

    Parameters
    ----------
    stmt : str
        String with the statements to be executed.  The statements may contain
        newlines, as long as they don't contain multi-line string literals.

    setup : str
        String with statements to be executed once initially. Execution time
        of these statements will not be timed. These are typically import
        statements. Not required if user set parameter `global` to `globals()`

    repeat : int
        Number of times the timer will time the execution of the codes. The
        final execution time will be the minimum time across all repeats.
        Defaults to 3.

    number : int
        Number of times the statements in `stmt` will be executed. Defaults to
        100.

    globals : dict, None
        Dictionary with namespace (typically `globals()`) If 'globals' is
        specified, the code will be executed within that namespace (as opposed
        to inside timeit's namespace).

    Examples
    --------
    Comparing Series with Lists

    Step 1: create a list which will hold 'setup' statements (in this case,
    imports and a very large array):

    >> setup_lst = [
    ...        'import pandas as pd', 
    ...        'import numpy as np',
    ...         # Create an array with 10,000 random numbers
    ...        'values = np.random.randint(0, 100, size=(10_000,))'
    ...         ]


    Step 2: Convert the setup_lst into a string 

    >> setup = '\n'.join(setup_lst)

    Step 3: Create a list with strings representing the statements (note,
            these are strings!)

    >> stmt_lst = [
    ...         # Create a pandas array and compute the sum of values
    ...         'pd.Series(values).sum()',
    ...         # Create a python list and compute the sum
    ...         'sum([x for x in values])',
    ...         ]

    Step 4: benchmark

    >> for stmt in stmt_lst:
    ...     benchmark(stmt=stmt, setup=setup, number=1000, repeat=10)


    """
    def _mk_lst(s, indent=''):
        """ Returns the string as a list of formatted commands
        """
        return [f'{indent}>> {x}' for x in s.splitlines() if x.strip() != '']

    # -------------------------------------------------------- 
    #   Prepares lines to be printed
    # -------------------------------------------------------- 
    indent = '  '
    #   This will keep track of the lines to print
    lines = []
    # Start the printout block
    block_sep = '-'*40
    lines.append('')
    lines.append(block_sep)
    lines.append('Running benchmark for statements:')
    
    #  Prepare statement messages for printout
    stmt_msgs = _mk_lst(stmt, indent=indent)
    lines.extend(stmt_msgs)

    #  Prepare setup messages for printout
    if setup != 'pass':
        setup_msgs = _mk_lst(setup, indent=indent)
        lines.append('Setup:')
        lines.extend(setup_msgs)
    #elif globals is not None:
    #    lines.append('Using current namespace')

    # -------------------------------------------------------- 
    #   Start the benchmark
    # -------------------------------------------------------- 
    lines.append(f'Benchmarking (best of {repeat} batches of {number} calls)...')

    # Prints the line so far
    for line in lines:
        print(line)
    lines = []

    #   Better to use the Timer class than the `timeit.repeat` method
    t = timeit.Timer(
                    stmt=stmt,
                    setup=setup,
                    globals=globals
                    )

    # Call timeit once so it creates all necessary objects (which takes a lot
    # of memory). This will help with the reliability of the memory stats 
    t.timeit(number=1)

    # Start mem trace...
    tracemalloc.start()
    # time the execution the statement
    times = t.repeat(repeat=repeat, number=number)
    # Get peak mem allocation and stop tracker
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    mem = _human_mem(peak)
    # Keep the best time
    res = min(times)
    # -------------------------------------------------------- 
    #   Results
    # -------------------------------------------------------- 
    lines.extend([
        'Results:',
        f'{indent}Best time: {round(res, 6)} seconds',
        f'{indent}Memory peak: {mem}',
        block_sep,
        ])
    for line in lines:
        print(line)
            
    


# ---------------------------------------------------------------------------- 
#   test
# ---------------------------------------------------------------------------- 
if __name__ == "__main__":
    
    setup_lst = [
           'import pandas as pd', 
           'import numpy as np',
            # Create an array with 1,000,000 random numbers
           'values = np.random.randint(0, 100, size=(10_000,))',
            ]


    #Step 2: Convert the setup_lst into a string 

    setup = '\n'.join(setup_lst)

    #Step 3: Create a list with strings representing the statements

    stmt_lst = [
            # Create a pandas array and compute the sum of values
            'pd.Series(values).sum()',
            # Create a python list and compute the sum
            'sum([x for x in values])',
            ]

    #Step 4: benchmark

    for stmt in stmt_lst:
        benchmark(stmt=stmt, setup=setup, number=1000, repeat=10)


