""" Config/options objects

         
"""
from __future__ import annotations

import pathlib
import inspect
import copy as _copy
import dataclasses as dc
import pprint as pp
import os
import sys

from ._typing import (
        ClassType,
        MutableMapping,
        )
from .defaults import DEFAULTS
from .decorators import (
        doc,
        fmt_doc_parm,
        )

PP_OPTS_PARMS = {
        'doctest_pp_opts_dflts': '''
            PPOpts(color=None,
                   indent='',
                   pretty=True,
                   width=60,
                   sort_dicts=False,
                   compact=False,
                   depth=None,
                   as_hdr=False,
                   underscore_numbers=True,
                   show_type=False,
                   df_info=False,
                   df_max_cols=None,
                   df_max_rows=None,
                   min_sep_width=40,
                   max_sep_width=60)
        ''',
        }
DOCTEST_PARMS = {
        'doctest_doctest_dflts': '''
            Doctest(print_docstring=False,
                    print_examples=True,
                    print_hdr=True,
                    print_mod=True,
                    verbose=False,
                    compileflags=None)
        ''',
        }
LOCS_PARMS = {
        'doctest_locs_dflts': '''
            Locs(dropbox_url=...
                 tk_prjdir=...
                 bk_dirname='_backup',
                 dbox_dirname='_dropbox',
                 ignore_dirs={'.idea',
                              '__pycache__',
                              '_backup',
                              '_dropbox'},
                 sys_dirs={'.idea', 'venv', '__pycache__'},
                 tk_cfg_modname='toolkit_config',
                 tk_zip_name='_tk_utils.zip',
                 venv_dirname='venv',
                 idea_dirname='.idea',
                 bk_dir=...
                 dbox_dir=...,
                 data_dirname=...
                 data_dir=...
                 lec_dirname=...
                 lec_dir=...
                 in_class_dirname=...
                 in_class_dir=...
                 branches=['prj_root',
                           'backup',
                           'dropbox',
                           'data',
                           'in_class',
                           'lectures',
                           'tk_utils',
                           'tk_cfg'])
        ''',
        }






CONFIG_PARMS = {
        'doctest_pp_opts_dflts': fmt_doc_parm(
            PP_OPTS_PARMS['doctest_pp_opts_dflts'],
            strip=True,
            ),
        'doctest_doctest_dflts': fmt_doc_parm(
            DOCTEST_PARMS['doctest_doctest_dflts'],
            strip=True,
            ),
        'doctest_locs_dflts': fmt_doc_parm(
            LOCS_PARMS['doctest_locs_dflts'],
            strip=True,
            ),
        'debug': fmt_doc_parm(
            """ 
            debug: bool, default False
                If True, display debug messages
            """,
            strip=True,
            ),
        }


def _chk_parms(opts_cls, parms, ignore_invalid):
    if ignore_invalid is True:
        parms = {k:v for k, v in parms.items() \
                if k in opts_cls._get_parm_names()}
    return parms

def mk_opts(
        opts_cls: ClassType,
        opts: dict | BaseOpts | None = None,
        copy: bool = False,
        parms: dict | None = None,
        ignore_invalid: bool = False,
        ) -> BaseOpts:
    """ Returns a possibly updated instance of `opts_cls`

    Parameters
    ----------
    opts_cls: ClassType
        A dataclass

    opts: dict, BaseOpts, optional
        An instance or dict

    copy: bool, default False
        If False, only copy objects as required.

    parms: dict, optional
        Dictionary with parms to update

    ignore_invalid: bool, default False
        If False, keys in `parms` dict must be valid parms of `opts_cls`


    """
    if parms is None:
        parms = {}
    elif isinstance(parms, MutableMapping):
        parms = _chk_parms(
                    opts_cls=opts_cls,
                    parms=parms,
                    ignore_invalid=ignore_invalid,
                    )
    else:
        err = f"Parm `parms` must be a dict or None, not {type(parms)}"
        raise ValueError(err)

    if not isinstance(opts, opts_cls):
        if opts is None:
            pass
        elif isinstance(opts, MutableMapping):
            opts = _chk_parms(
                        opts_cls=opts_cls,
                        parms=opts,
                        ignore_invalid=ignore_invalid,
                        )
            parms = opts | parms
        else:
            err = f"Parm `opts` must be '{opts_cls}' or dict, not {type(opts)}"
            raise ValueError(err)
        return opts_cls(**parms)
    elif copy is False and len(parms) == 0:
        return opts
    else:
        parms = opts._asdict() | parms
        return opts_cls(**parms)


@dc.dataclass(kw_only=True)
class BaseDC:
    """ Base dataclass object

    Parameters
    ----------

    Methods
    -------

    """
    

    @classmethod
    def _get_parm_names(cls, ignore_underscored: bool = False):
        """ Returns a list with the parameter names

        """
        out = [x.name for x in dc.fields(cls)]
        # Add 
        if ignore_underscored is True:
            out = [x for x in out if not x.startswith('_')]
        return out

    def __str__(self):
        width = DEFAULTS['pp']['width']
        return pp.pformat(self, width=width)


    def _asdict(
            self, 
            dict_factory: object = dict,
            ):
        """
        """
        return dc.asdict(self, dict_factory=dict_factory)


    def _replace(self, **kargs):
        """ Returns a copy of the instance, optionally replacing parameters
        with values in `kargs`
        """
        return dc.replace(self, **kargs)


    def _update(self, **kargs):
        for k, v in kargs.items():
            setattr(self, k, v)



@dc.dataclass(kw_only=True)
class BaseOpts(BaseDC):
    """ Base dataclass object. Does not allow new attributes to be created

    Parameters
    ----------

    Methods
    -------

    """

    def __str__(self):
        return pformat(self)

    def __setattr__(self, attr, value):
        """Only allows setting field values"""
        parms = self._get_parm_names()

        #print(str(sig))
        #raise
        if attr.startswith('_'):
            pass
        elif attr not in parms:
            cls_name = self.__class__.__name__
            sig = ',\n'.join(f"    {k}: {v.annotation}" for k, v in \
                    inspect.signature(self.__class__).parameters.items())
            err = f"Cannot set new attribute '{attr}' to\n{cls_name}(\n{sig})" 
            raise Exception(err)
        object.__setattr__(self, attr, value)
    

@doc(indent=1, parms=PP_OPTS_PARMS)
@dc.dataclass(kw_only=True)
class PPOpts(BaseOpts):
    """ Options for pretty printing

    Examples
    --------
    >>> import tk_utils
    >>> opts = tk_utils.opts.PPOpts(color=None, indent='', as_hdr=False, pretty=True, width=60)
    >>> print(opts)
    {doctest_pp_opts_dflts}
    """
    color: str | None = DEFAULTS['pp']['color']
    indent: str = DEFAULTS['pp']['indent']
    pretty: bool = DEFAULTS['pp']['pretty']
    width: int  = DEFAULTS['pp']['width']
    sort_dicts: bool = DEFAULTS['pp']['sort_dicts']
    compact: bool = DEFAULTS['pp']['compact']
    depth: int | None = DEFAULTS['pp']['depth']
    as_hdr: bool = DEFAULTS['pp']['as_hdr']
    underscore_numbers: bool = DEFAULTS['pp']['underscore_numbers']
    show_type: bool = DEFAULTS['pp']['show_type']
    df_info: bool = DEFAULTS['pp']['df_info']
    df_max_cols: int | None = DEFAULTS['pp']['df_max_cols']
    df_max_rows: int | None = DEFAULTS['pp']['df_max_rows']
    min_sep_width: int = DEFAULTS['pp']['min_sep_width']
    max_sep_width: int | None = DEFAULTS['pp']['max_sep_width']


    def __post_init__(self):

        if self.max_sep_width is None:
            self.max_sep_width = self.width




@dc.dataclass(kw_only=True)
class Locs(BaseOpts):
    """ Package configuration

    Parameters
    ----------

    Examples
    --------

    """
    dropbox_url: str = DEFAULTS['locs']['dropbox_url']
    tk_prjdir: str | pathlib.Path 
    bk_dirname: str = DEFAULTS['locs']['bk_dirname']
    dbox_dirname: str = DEFAULTS['locs']['dbox_dirname']
    ignore_dirs: set | None = None 
    sys_dirs: set | None = None 
    tk_cfg_modname: str = DEFAULTS['locs']['tk_cfg_modname']
    tk_zip_name: str = DEFAULTS['locs']['tk_zip_name']    
    venv_dirname: str = 'venv'
    idea_dirname: str = '.idea'
    bk_dir: pathlib.Path | None = None
    dbox_dir: pathlib.Path | None = None
    data_dirname: str = DEFAULTS['locs']['data_dirname']
    data_dir: pathlib.Path | None = None
    lec_dirname: str = DEFAULTS['locs']['lec_dirname']
    lec_dir: pathlib.Path | None = None
    in_class_dirname: str = DEFAULTS['locs']['in_class_dirname']
    in_class_dir: pathlib.Path | None = None
    branches: list | None = None 


    def __post_init__(self):

        mutable_attrs = [
                'ignore_dirs',
                'sys_dirs',
                'branches',
                ]
        for attr in mutable_attrs:
            if getattr(self, attr) is None:
                setattr(self, attr, DEFAULTS['locs'][attr])

        if isinstance(self.tk_prjdir, str):
            self.tk_prjdir = pathlib.Path(self.tk_prjdir)

        if self.bk_dir is None:
            self.bk_dir = self.tk_prjdir.joinpath(self.bk_dirname)

        if self.dbox_dir is None:
            self.dbox_dir = self.tk_prjdir.joinpath(self.dbox_dirname)

        if self.data_dir is None:
            self.data_dir = self.tk_prjdir.joinpath(self.data_dirname)
        if self.lec_dir is None:
            self.lec_dir = self.tk_prjdir.joinpath(self.lec_dirname)
        if self.in_class_dir is None:
            self.in_class_dir = self.tk_prjdir.joinpath(self.in_class_dirname)


@dc.dataclass(kw_only=True)
class Doctest(BaseOpts):
    """ Package configuration

    Parameters
    ----------

    Examples
    --------

    """
    print_docstring: bool = DEFAULTS['doctest']['print_docstring']
    print_examples: bool = DEFAULTS['doctest']['print_examples']
    print_hdr: bool = DEFAULTS['doctest']['print_hdr']
    print_mod: bool = DEFAULTS['doctest']['print_mod']
    verbose: bool = DEFAULTS['doctest']['verbose']
    compileflags: list | None = DEFAULTS['doctest']['compileflags']




@dc.dataclass(kw_only=True)
class PathInfo(BaseOpts):
    """ Object representing some important file/folder 
    under the PyCharm project folder

    Parameters
    ----------
    name: str
        Internal name of this file/folder

    pth: path-like
        Where this folder should be located

    actual_pth: str
        Actual path to this file/folder. May differ
        from pth because of capitalization

    arrow: str, optional
        Arrow pointing to this file/folder

    expected_branch: str
        A string representation of this branch


    """
    name: str
    pth: pathib.Path
    actual_pth: pathlib.Path | None
    #expected_branch: str
    #children: dict[str, PathInfo] 
    arrow: str | None = None

    def __post_init__(self):
        if self.actual_pth is None or self.pth.exists():
            self.actual_pth = self.pth


    @property
    def _exists(self) -> bool:
        return self.actual_pth.exists()

    @property
    def _is_name_ok(self):
        if self._exists:
            return self.actual_pth.name.lower() == self.pth.name
        else:
            return False

    @property
    def _is_lower(self):
        if self._exists:
            return self.actual_pth.name.lower() == self.actual_pth.name
        else:
            return False


@dc.dataclass(kw_only=True)
class PrjBranches(BaseOpts):
    """ Information about the PyCharm project

    Parameters
    ----------

    """
    prj_root: PathInfo
    data: PathInfo
    backup: PathInfo
    dropbox: PathInfo
    tk_utils: PathInfo
    in_class: PathInfo
    lectures: PathInfo
    tk_cfg: PathInfo
    installer: PathInfo

def mk_prj_branches(tk_prjdir: pathlib.Path):
    """
    """
    branch_names = {
            'prj_root': DEFAULTS['locs']['prj_dirname'],
            'backup': DEFAULTS['locs']['bk_dirname'],
            'dropbox': DEFAULTS['locs']['dbox_dirname'],
            'data': DEFAULTS['locs']['data_dirname'],
            'in_class': DEFAULTS['locs']['in_class_dirname'],
            'lectures': DEFAULTS['locs']['lec_dirname'],
            'tk_utils': DEFAULTS['locs']['pkg_name'],
            'tk_cfg': DEFAULTS['locs']['tk_cfg_filename'],
            'installer': DEFAULTS['locs']['installer_modname'],
            }
    tk_root = tk_prjdir.parent.joinpath(branch_names['prj_root'])
    actual_tk_root = tk_prjdir
    arrows = {
            'prj_root': "PyCharm project folder",
            'data': 'Data folder',
            'dropbox': 'Mirror of Dropbox shared folder',
            'backup': "Backup folder",
            'in_class': "Codes discussed in class",
            'lectures': "Companion codes",
            'tk_utils': "This package (DO NOT MODIFY)",
            'tk_cfg': 'Your config module',
            }


    # TODO: Going forward it's better to use case-insensitive glob (only
    # avalable >= 3.12)
    actual_pths = {}
    actual_to_names = {v:k for k, v in branch_names.items()}
    for pth in tk_prjdir.iterdir():
        actual = pth.name.lower()
        if actual in actual_to_names:
            name = actual_to_names[actual]
            actual_pths[name] = pth


    prj_root = {
            'pth': tk_root,
            'name': 'prj_root',
            'arrow': arrows['prj_root'],
            'actual_pth': actual_tk_root,
            }
    kargs = {
            'prj_root': PathInfo(**prj_root),
            }

    for name, pthname in branch_names.items():
        if name in kargs:
            continue

        pth = tk_root.joinpath(pthname)

        if name in actual_pths:
            actual_pth = actual_tk_root.joinpath(actual_pths[name])
        else:
            actual_pth = None

        kw = {
                'pth': pth,
                'name': name,
                'actual_pth': actual_pth,
                'arrow': arrows[name] if name in arrows else None,
            }
        kargs[name] = PathInfo(**kw)
    return PrjBranches(**kargs)




@doc(indent=1, parms=CONFIG_PARMS)
@dc.dataclass(kw_only=True)
class Config(BaseOpts):
    """ Package configuration

    Parameters
    ----------

    Examples
    --------
    >>> import tk_utils
    >>> cfg = tk_utils.opts.Config()
    >>> print(cfg.debug)
    False
    >>> print(cfg.pp.pretty)
    True
    >>> print(cfg.pp.width)
    60

    """
    # TODO: This should be added to the docstest
    # >>> print(cfg)
    #Config(pp={doctest_pp_opts_dflts},
    #       doctest={doctest_doctest_dflts},
    #       locs={doctest_locs_dflts})
    #branches=PrjBranches(...))


    debug: bool | None = None
    pp: PPOpts | None = None
    doctest: Doctest | None = None
    locs: Locs | None = None
    branches: PrjBranches | None = None

    def __post_init__(self):

        # This will be determined at import time and will not be updated
        self._cwd = os.getcwd()
        self._last_sys_path = sys.path[-1]

        # Init objs
        self.reset()

    def reset_branches(self):
        """ Creates an instance of Setup
        """
        self.branches = mk_prj_branches(self.locs.tk_prjdir)

    def reset(self):
        self.debug = DEFAULTS['debug']
        self.pp = PPOpts()
        self.doctest = Doctest()
        self.locs = Locs(tk_prjdir=self._cwd)
        # Must be after self.locs
        self.reset_branches()
        #self.setup = Setup()


cfg = Config()


def pformat(
        obj: object, 
        **kargs):
    """
    """
    _kargs = {
            'width': cfg.pp.width,
            'sort_dicts': cfg.pp.sort_dicts,
            'compact': cfg.pp.compact,
            'depth': cfg.pp.depth,
            'underscore_numbers': cfg.pp.underscore_numbers,
            } | kargs
    return pp.pformat(obj, **_kargs)



