""" Docstring utils

         
"""
from __future__ import annotations

import inspect
import pydoc

from ._pp import colorize


def pretty_sig(func, sig):
    """
    """
    indent = ' '*len(func.__name__)
    out = str(sig)
    if len(out) > 60:
        out = f',\n{indent}'.join(out.split(','))
    return out


def func_doc(func, name_only: bool = False):
    """ Returns the documentation of a function
    """
    sig = inspect.signature(func, eval_str=True)
    sig_str = pretty_sig(func, sig)
    #fname = f"\033[4m{func.__name__}{sig}\033[0m"
    fname = colorize(f"{func.__name__}{sig_str}", 'green')
    if name_only is True:
        return fname
    else:
        docstring = func.__doc__.strip()
        return f"""{fname}: 
        
    {docstring}
    """

def render_doc(thing):
    """Wrapper around pydoc.render_doc
    """
    
    renderer = pydoc._PlainTextDoc()

    object, name = pydoc.resolve(thing, 0)
    desc = pydoc.describe(object)
    module = inspect.getmodule(object)

    if name and '.' in name:
        desc += ' in ' + name[:name.rfind('.')]

    elif module and module is not object:
        desc += ' in module ' + module.__name__

    if not (inspect.ismodule(object) or
              inspect.isclass(object) or
              inspect.isroutine(object) or
              inspect.isdatadescriptor(object) or
              pydoc._getdoc(object)):
        # If the passed object is a piece of data or an instance,
        # document its available methods instead of its value.
        if hasattr(object, '__origin__'):
            object = object.__origin__
        else:
            object = type(object)
            desc += ' object'


    return  (desc, renderer.document(object, name))

def help(
        obj, 
        indent: str = '',
        indent_first: bool = False,
        ):
    """ Similar to the built-in help function but returns a string instead of
    calling help from an interactive session

    Parameters
    ----------
    obj: object
        Any object

    indent: str, optional
        If given, used to indent each line in output

    indent_first: bool, default False
        If False, and indent is given, skip indentation of the first line
    """
    desc, doc = render_doc(obj)

    if len(indent) > 0:
        doc = '\n'.join(f"{indent}{x}" for x in doc.splitlines())

        if indent_first is False:
            doc = doc.lstrip()
    return doc
    


def mk_tk_utils_doc(
        funcs: list,
        ):
    """
    """
    _func_desc = '\n'.join([func_doc(x) for x in funcs])
    _func_list = '\n\n'.join([f"{func_doc(x, name_only=True)}" for x in funcs])
    _func_header = colorize("Functions", 'green')

    return f""" The `tk_utils` package. 

IMPORTANT: This zip file should be placed directly under the `toolkit` folder:

    toolkit/   
    | ...
    |__ tk_utils.zip            <- This file
    |__ toolkit_config.py       <- Your config file (REQUIRED)

IMPORTANT: This module is should not be modified. Also, it includes Python
concepts/libraries we did not (and will not) discuss in this course. Please
use this module "as is" and do not worry about the implementation.

IMPORTANT: This module requires a correctly configured `toolkit_config.py`
module.  If you followed the instructions in Lecture 4.4, you are all set!

This module implements the following functions:

{_func_list}

Each function is documented below:

{_func_header}
---------

{_func_desc}


"""

