""" TK utils

"""
from __future__ import annotations

import zipfile
import shutil
import os
import pathlib
import requests
import datetime as dt

from .. import (
        opts,
        _pp,
        )
from ._utils import (
        walk,
        copytree,
        CopyTree,
        copyfile,
        has_same_files,
        clear_console,
        )

cfg = opts.cfg

__all__ = [
        'backup',
        'sync_dbox',
        'walk',
        'copyfile',
        'CopyTree',
        'copytree',
        'has_same_files',
        'TKOrganizer',
        'clear_console',
        ]

def _print_msg(
        msg: str, 
        sep: bool = True,
        quiet: bool = False, 
        color: str = 'bold',
        indent: str = '',
        ):
    """ Prints a header message
    """
    lines = _pp.MsgLines()
    lines.add(msg, sep=sep, color=color, indent=indent)
    lines.print(quiet=quiet)


def _hdr_msg(msg: str):
    return _pp.fmt_msg(msg, as_hdr=True, color='bold')


class ZipFile(zipfile.ZipFile):
    """ Patched ZipFile class to prevent errors of the type

        ValueError: Empty filename.

        when calling extractall
    """

    def extractall(self, path=None, members=None, pwd=None):
        """Extract all members from the archive to the current working
           directory. `path' specifies a different directory to extract to.
           `members' is optional and must be a subset of the list returned
           by namelist().
        """
        if members is None:
            members = self.namelist()
        if path is None:
            path = os.getcwd()
        else:
            path = os.fspath(path)

        for zipinfo in members:
            if zipinfo == '/':
                continue
            self._extract_member(zipinfo, path, pwd)

def _unzip(tmp, dst):
    """  Wrapper around extractall

    """
    try:
        with zipfile.ZipFile(tmp) as zf:
            zf.extractall(dst)
    except:
        with ZipFile(tmp) as zf:
            zf.extractall(dst)




class TKOrganizer:
    """

    Notes
    -----
    toolkit/            <- self.tk_root
    |__ _backup         <- self.bk_root
    |   |__ _tmp/       <- self.bk_tmp
    |   |   |__ TMP_FOLDER_PLEASE_LEAVE_ALONE
    |__ _dropbox/
    |   |__ WILL_BE_ERASED_BEFORE_EVERY_SYNC
    """

    def __init__(
            self,
            ):

        self.tk_root = cfg.locs.tk_prjdir
        self.dbox_root = cfg.locs.dbox_dir
        self.bk_root = cfg.locs.bk_dir
        self.tk_utils = self.tk_root.joinpath('tk_utils')
        self.tk_utils_dbox = self.dbox_root.joinpath('tk_utils')

        self._bkdir = None
        self._dbox_bk = None
        self._tk_utils_bk = None

        self.exclude_bk_dirnames = {
                '.idea',
                }


    def _mk_bkdir(self) -> pathlib.Path:
        """
        """
        now = dt.datetime.now().strftime('%Y_%m_%d_%H_%M_%S')
        bkdir = self.bk_root.joinpath(now)
        if not bkdir.exists():
            bkdir.mkdir(parents=True)
        else:
            raise Exception(f"Backup folder already exists: {bkdir}")
        return bkdir

    @property
    def bkdir(self) -> pathlib.Path:
        """ Creates the path to a dated backup folder
        """
        if self._bkdir is None:
            self._bkdir = self._mk_bkdir()
        return self._bkdir

    @property
    def dbox_bk(self) -> pathlib.Path:
        """ Location of the _dropbox folder inside bk
        """
        if self._dbox_bk is None:
            self._dbox_bk = self.bkdir.joinpath(self.dbox_root.name)
        return self._dbox_bk

    @property
    def tk_utils_bk(self) -> pathlib.Path:
        """ Location of the tk_utils folder inside bk
        """
        if self._tk_utils_bk is None:
            self._tk_utils_bk = self.bkdir.joinpath(self.tk_utils.name)
        return self._tk_utils_bk

    def backup(
            self,
            show_folder: bool = False,
            quiet: bool = False,
            ):
        """ Backup all files under tk_root
        """

        msg = _pp.MsgLines()
        msg.add("Backing up PyCharm project folder...", sep=True, bold=True)
        if show_folder is True or not self.bk_root.exists():
            msg.add(f'''Destination:
                
        {self.tk_root.name}/          <- PyCharm project folder
        |__ {self.bk_root.name}/
        |   |__ {self.bkdir.name}/      <- New folder''', strip=True, newline=True)
        msg.print(quiet=quiet)

        for src in self.tk_root.iterdir():
            if src == self.bk_root or src.name in self.exclude_bk_dirnames:
                continue
            elif src.is_dir():
                copytree(src, self.bkdir, raise_if_exists=True)
            elif src.is_file():
                copyfile(src, self.bkdir.joinpath(src.name), raise_if_exists=True)
            
        msg = _pp.MsgLines()
        msg.add('Done', sep=False, color=None)
        msg.print(quiet=quiet)


    def move_to_tmp(self, pth: pathlib.Path) -> pathlib.Path | None:
        """ Rename a file or folder so it includes a .tmp extension. If pth
        does not exist, return None. Otherwise, returns the tmp path
        """
        if not pth.exists():
            return None
        else:
            # TODO: Use _utils.mk_tmp_file instead
            tmp = pth.with_suffix('.tmp')
            i = 0
            while tmp.exists():
                i += 1
                tmp = tmp.with_suffix('').with_suffix(f'.tmp{i}')
            pth.rename(tmp)
            return tmp

    def move_from_tmp(self, tmp: pathlib.Path):
        """ Undoes the move_from_tmp operation
        """
        dst = tmp.with_suffix('')

        if not dst.exists():
            tmp.rename(dst)
        elif dst.is_dir():
            children = [x for x in dst.iterdir()]
            if len(children) > 0:
                err = f"Dir not empty: {dst}"
                raise Exception(err)
            dst.rmdir()
        else:
            err = f"Path is a file: {dst}"
            raise Exception(err)
        tmp.rename(dst)


    def unzip_dbox(self):
        """ Downloads and unzips dbox folder
        """
        # Create a tmp file
        # TODO: Use _utils.mk_tmp_file instead
        i = 0
        tmp = self.tk_root.joinpath(f'toolkit_dropbox{i}.zip')
        while tmp.exists():
            i += 1
            tmp = self.tk_root.joinpath(f'toolkit_dropbox{i}.zip')

        r = requests.get(cfg.locs.dropbox_url)
        with open(tmp, 'wb') as fobj:
            fobj.write(r.content)
        # TODO: Use my updated class
        if not self.dbox_root.exists():
            self.dbox_root.mkdir(parents=True)
        _unzip(tmp=tmp, dst=self.dbox_root)
        #with zipfile.ZipFile(tmp) as zf:
        #    zf.extractall(self.dbox_root)
        tmp.unlink()


    def sync_dbox(
            self,
            quiet: bool = False,
            ):
        """ Must only be called after backup
        """
        msg = _pp.MsgLines()
        msg.add("Downloading Dropbox files...")
        msg.print(quiet=quiet)

        # Move the current folder to a tmp file
        dbox_root_tmp = self.move_to_tmp(self.dbox_root)


        if not self.dbox_root.exists():
            self.dbox_root.mkdir(parents=True)
        try:
            self.unzip_dbox()
        except Exception as e:
            if dbox_root_tmp is not None:
                self.move_from_tmp(dbox_root_tmp)
            raise

        # Delete tmp
        if (
                self.dbox_bk.exists() 
                and dbox_root_tmp is not None
                and dbox_root_tmp.exists()
                and has_same_files(self.dbox_bk, dbox_root_tmp)):
            shutil.rmtree(dbox_root_tmp)
        elif dbox_root_tmp is not None:
            # Move to backup
            shutil.move(dbox_root_tmp, self.bkdir)

        _print_msg('Done', sep=False, color=None, quiet=quiet)

    def update_tk_utils(
            self,
            quiet: bool = True,
            ):
        """
        """
        if not self.tk_utils_dbox.exists():
            err = f"tk_utils not found inside _dropbox"
            raise Exception(err)

        msg = _pp.MsgLines()
        msg.add("Updating the tk_utils module...")
        msg.print(quiet=quiet)

        # Move the current folder to a tmp file
        tk_utils_tmp = None
        if self.tk_utils.exists():
            tk_utils_tmp = self.move_to_tmp(self.tk_utils)
        try:
            copytree(self.tk_utils_dbox, self.tk_root, raise_if_exists=True)
        except Exception as e:
            if tk_utils_tmp is not None:
                self.move_from_tmp(tk_utils_tmp)
            raise

        # Delete tmp
        if (
                self.tk_utils_bk.exists() 
                and tk_utils_tmp is not None
                and tk_utils_tmp.exists()
                and has_same_files(self.tk_utils_bk, tk_utils_tmp)):
            shutil.rmtree(tk_utils_tmp)

        _print_msg('Done', sep=False, color=None, quiet=quiet)


    def copy_new_files(
            self,
            quiet: bool = False,
            ):
        """ Copies new files from _dropbox into the PyCharm project folder
        """
        if not self.dbox_root.exists():
            err = "Could not find _dropbox folder, please run tk_utils.sync_dbox()"
            raise Exception(err)

        c = CopyTree(
                src=self.dbox_root,
                dst=self.tk_root,
                children_only=True,
                )
        if len(c.to_copy_ntups) == 0:
            print('')
            print("All Dropbox files are available in your Project folder!")
            print("No files will be copied")
            print('')
            return

        arrows_new = {}
        arrows_no_exist = {}
        dst_pths = []
        for tup in c.to_copy_ntups:
            arrows_new[tup.dst.name] = "NEW FILE"
            arrows_no_exist[tup.dst.name] = "In Dropbox, not in Prj folder"
            dst_pths.append(tup.dst)

        dst_pths = c.add_parents(paths=dst_pths, root=c.dst)
        if c.dst not in dst_pths:
            dst_pths.insert(0, c.dst)
        dst_tree = _pp.dirtree(
                paths=dst_pths,
                root=c.dst,
                file_arrows=arrows_new,
                )

        _print_msg(
                "The following Dropbox files/folders are NOT in your project folder",
                )
        print(dst_tree)
        print('')

        print(f"Would you like to copy these files/folders into your project folder?")    
        print('')
        print(f"NOTE: Only NEW files will be copied!")
        print('')
        res = _pp.ask_yes()
        if res:
            c.copytree()
            print('')
            print("Done")
            print('')
            _print_msg("The following new files are now available:", sep=True)
            print('')
            print(dst_tree)
            print('')



def backup(
        show_folder: bool = False, 
        quiet: bool = False,
        ) -> pathlib.Path | None:
    """Backup files under the toolkit project folder

    This function will copy all (non-system) files under "toolkit" to a
    "dated" folder inside "toolkit/_backup". A new dated folder will be
    created every time this function is called.

    This function will exclude system files, hidden files (e.g., files
    starting with '.'),  the Dropbox folder, and the backup folder itself.

    Parameters
    ----------
    show_folder : bool
        If True, prints the location of the destination folder.
        Ignored if the "_backup" folder does not exist (will always be printed)
        Defaults to False

    quiet: bool, optional
        If True, do not display any messages.
        Defaults to False

    Usage
    -----
    >> import tk_utils
    >> tk_utils.backup()


    Example
    -------
    Suppose you only have the following files under toolkit:

     toolkit/               <- PyCharm project folder 
     |
     |__ toolkit_config.py
     |__ tk_utils/          <- this package
    
    After the backup, your toolkit folder will look like this:
    
     toolkit/               <- PyCharm project folder 
     |
     |__ _backup/                       <- Will be created 
     |  |__ <YYYY_MM_DD_HH_MM_SS>/          <- Represents the time of the backup
     |  |  |__ toolkit_config.py                <- backup
     |  |  |__ tk_utils/                        <- backup
     |
     |__ toolkit_config.py              <- original (not modified)
     |__ tk_utils/                      <- original (not modified)


    """
    c = TKOrganizer()
    c.backup(show_folder=show_folder, quiet=quiet)


def sync_dbox(
        quiet: bool = False,
        update_tk_utils: bool = True,
        copy_new_files: bool = True,
        ) -> pathlib.Path | None:
    """ Downloads the files from the Dropbox shared folder into "_dropbox".

    This function will download all files from the shared folder under
    DROPBOX_URL into the following folder:

    toolkit/
    |__ _dropbox/       <- Destination

    Files under "_dropbox" will be replaced.

    Parameters
    ----------
    quiet: bool, optional
        If True, do not display any messages.
        Defaults to False

    update_tk_utils: bool, default True
        If True, update tk_utils with the most recent version in dropbox

    copy_new_files: bool, default True
       Allow the user to copy new files.

    Usage
    -----
    To synchronize the Dropbox folder, open the PyCharm console and type:

        >> import tk_utils
        >> tk_utils.sync_dbox()

    This will download the current version of the Dropbox shared folder and
    place the files under 'toolkit/_dropbox'. All existing files inside
    _dropbox will be replaced:

     <DROPBOX>/
     |__ toolkit/            <- Dropbox shared folder (SOURCE)
     |   |__ data/           
     |   |__ lectures/       
     |   |    ...


     toolkit/               <- PyCharm project folder 
     |
     |__ _dropbox/           <- DESTINATION (only files under this folder will be updated)
     |   |__ data/               <- Same as <DROPBOX>/toolkit/data above
     |   |__ lectures/           <- Same as <DROPBOX>/toolkit/lectures above
     |   |   ...                 <- Same as <DROPBOX>/toolkit/... above
     | ...
     |__ data/               <- NOT a destination (will not be updated)
     |__ lectures/           <- NOT a destination (will not be updated)
     |   ...                 <- NOT a destination (will not be updated)
    
    If the _dropbox folder does not exist, it will be created.

    Returns
    -------
    pathlib.Path
        Path to the backup folder 


    """
    c = TKOrganizer()
    c.backup(quiet=quiet)
    c.sync_dbox(quiet=quiet)
    if update_tk_utils:
        c.update_tk_utils()
    if copy_new_files:
        c.copy_new_files(quiet=quiet)










