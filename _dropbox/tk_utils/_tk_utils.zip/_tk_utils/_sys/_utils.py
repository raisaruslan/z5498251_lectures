""" System/shell utilities

         
"""
from __future__ import annotations

import zipfile
import shutil
import pathlib
import os
import requests
import datetime as dt
from collections import namedtuple

from .. import (
        opts,
        _pp,
        decorators,
        )
from .._utils import (
        as_path,
        )
from .parms import PARMS


__all__ = [
        ]

cfg = opts.cfg
BUFSIZE = 8*1024

def is_same_cnts(f1: pathlib.Path, f2: pathlib.Path):
    """ Returns True if same content.
    Taken from Python's filecmp.py
    """
    bufsize = BUFSIZE
    with open(f1, 'rb') as fp1, open(f2, 'rb') as fp2:
        while True:
            b1 = fp1.read(bufsize)
            b2 = fp2.read(bufsize)
            if b1 != b2:
                return False
            if not b1:
                return True

#def as_path(pth: str | pathlib.Path) -> pathlib.Path:
#    """ Ensure `pth` is a pathlib.Path instance
#    """
#    return pth if isinstance(pth, pathlib.Path) else pathlib.Path(pth)
#

def _clear_console():
    """ Clears the Python console
    """
    if os.name == 'nt': 
        os.system('cls')
    else:
        os.system('clear')


def clear_console(ignore_errors: bool = True):
    """ Clears the Python console
    """
    raise NotImplementedError("Not implemented")
    if ignore_errors is True:
        try:
            _clear_console()
        except:
            pass
    else:
        _clear_console()


def chg_src_root(
        src: pathlib.Path,
        src_root: pathlib.Path,
        dst_root: pathlib.Path,
        ) -> pathlib.Path:
    """ Changes the root of a source file/folder from `src_root` to `dst_root`

    Parameters
    ----------
    src: path-like
        Source path
    src_root: path-like
        Some parent of `src`
    dst_root: path-like
        New parent for `src`
    """
    rsrc = src.relative_to(src_root)
    return dst_root.joinpath(rsrc)


def has_same_files(
        dir1: pathlib.Path,
        dir2: pathlib.Path,
        **kargs) -> bool:
    """ Returns True if the two directories contain no files or the same files
    """
    if dir1.is_relative_to(dir2):
        err = f"Path `dir1` cannot be relative to `dir2`"
        raise ValueError(err)
    elif dir2.is_relative_to(dir1):
        err = f"Path `dir2` cannot be relative to `dir1`"
        raise ValueError(err)

    kargs = kargs | {
            'files_only': True,
            'recursive': True,
            }
    # Walks both dirs, keep only files
    dir1_files = set(walk(root=dir1, **kargs))
    dir2_files = set(walk(root=dir2, **kargs))

    for src in set(dir1_files):
        dst = chg_src_root(src=src, src_root=dir1, dst_root=dir2)
        if is_same_cnts(src, dst):
            dir1_files.remove(src)
            if dst in dir2_files:
                dir2_files.remove(dst)

    return len(dir1_files) == 0 and len(dir2_files) == 0


def _parm_as_set(
        name: str, 
        value: str|list|set|None,
        none_is_empty: bool = True,
        ) -> set | None:
    """ Convert a parameter named `name` with value `value` to a set
    """
    if isinstance(value, set):
        pass
    elif isinstance(value, str):
        value = {value}
    elif value is None:
        if none_is_empty is True:
            value = set([])
    elif isinstance(value, (list, tuple)):
        value = set(value)
    else:
        err = f"Invalid type for `{name}`: {type(value)}" 
        raise ValueError(err)
    return value

def mk_tmp_file(pth: pathlib.Path,):
    """ Creates a temp file from pth by adding a '.{i}.tmp', suffix
    """
    i = 0
    tmp = pth.with_suffix(f".{i}.tmp")
    while tmp.exists():
        i += 1
        tmp = pth.with_suffix(f".{i}.tmp") 
    return tmp


@decorators.doc(indent=1, parms=PARMS['walk'])
def walk(
        root: pathlib.Path,
        exclude: set[str] | None = None,
        include: set[str] | None = None,
        filter_files: Callable | None = None,
        filter_dirs: Callable | None = None,
        dirs_only: bool = False,
        files_only: bool = False,
        recursive: bool = True,
        ) -> list[pathlib.Path]:
    """ Returns a list of paths under root

    Parameters
    ----------
    {root}
    {exclude}
    {include}
    {filter_files}
    {filter_dirs}
    {dirs_only}
    {files_only}
    {recursive}

    """
    exclude = _parm_as_set('exclude', exclude, none_is_empty=True)
    include = _parm_as_set('include', include, none_is_empty=False)

    if files_only is True and dirs_only is True:
        err = f"Parms `files_only` and `dirs_only` cannot be both True"
        raise ValueError(err)

    # For recursion
    kargs = {
            'exclude': exclude,
            'include': include,
            'files_only': files_only,
            'dirs_only': dirs_only,
            'filter_dirs': filter_dirs,
            'filter_files': filter_files,
            'recursive': recursive,
            }

    out = [] if files_only is True else [root]

    for pth in root.iterdir():
        if pth.name in exclude:
            continue
        elif include is not None and pth.name not in include:
            continue
        elif pth.is_dir():
            if filter_dirs is not None and filter_dirs(pth) is False:
                continue
            elif recursive is True:
                out.extend(walk(pth, **kargs))
            else:
                out.append(pth)
        elif pth.is_file() and dirs_only is False:
            if filter_files is not None and filter_files(pth) is False:
                continue
            else:
                out.append(pth)
    return out


def copyfile(
        src: str | pathlib.Path, 
        dst: str | pathlib.Path,
        raise_if_exists: bool = False,
        ) -> bool:
    """ Copies a file from `src` to `dst` if dst does not exist. If `dst` does
    not exist, create destination parent folders. Raises an exception if `src`
    is not an existing file or if `src` is the same as `dst`.

    Parameters
    ----------
    src: path-like
        Source file to copy

    dst: path-like
        Destination path. 

    Returns
    -------
    bool
        Returns True if file was copied and False if dst file exists

    """
    (src, dst) = (as_path(src), as_path(dst))
    if not src.exists():
        raise FileNotFoundError(f"File does not exist: {dst}")
    elif src == dst:
        raise Exception(f"Parms `src` and `dst` point to the same file: {src}")
    elif not src.is_file():
        raise Exception(f"Parm `src` must be a file: {src}")

    if dst.exists():
        if raise_if_exists:
            err = f"Destination file exists: {dst}"
            raise Exception(err)
        else:
            return False
    else:
        if not dst.parent.exists():
            dst.parent.mkdir(parents=True)
        shutil.copy2(src, dst)
        return True




# TODO: Clean this up. All we need is the tups with the src,dst 
# paths and the copytree method
@decorators.doc(indent=1, parms=PARMS['copytree'])
class CopyTree:
    """ Utility to copy the directory `src` into the directory `dst`. Only
    files which do not exist in `dst` will be copied.

    Parameters
    ----------
    {src}
    {dst}
    {dry_run}
    {exclude}
    {include}
    {filter_files}
    {filter_dirs}
    {dirs_only}
    {files_only}

    children_only: bool, default False
        If True, copies the entries of src into dst (instead
        of copying the folder `src` into `dst`)

    """
    SRC_DST_NTUP = namedtuple('SrcDst', ['src', 'dst'])

    def __init__(
            self,
            src: str | pathlib.Path, 
            dst: str | pathlib.Path,
            exclude: set[str] | None = None,
            include: set[str] | None = None,
            filter_files: Callable | None = None,
            filter_dirs: Callable | None = None,
            dirs_only: bool = False,
            files_only: bool = False,
            children_only: bool = False,
            dry_run: bool = False,
            raise_if_exists: bool = False,
            ):
        self.src = as_path(src)
        self.dst = as_path(dst)
        self.dry_run = dry_run
        self.raise_if_exists = raise_if_exists
        self.children_only = children_only

        self.walk_opts = {
            'exclude': exclude,
            'include': include,
            'filter_files': filter_files,
            'filter_dirs': filter_dirs,
            'dirs_only': dirs_only,
            'files_only': files_only,
            }

        self._path_ntups = None
        self._to_copy_ntups = None


    def get_src_paths(self):
        """
        """
        return walk(root=self.src, **self.walk_opts)


    def mk_path_ntups(self):
        """ Returns a list of namedtuples with each source and its destination counterpart
        """
        out = [self.SRC_DST_NTUP(src=self.src, dst=self.dst)]
        if self.children_only is True:
            root = self.src
        else:
            root = self.src.parent
        for src in self.get_src_paths():
            if src == self.src:
                continue
            rsrc = src.relative_to(root)
            dst = self.dst.joinpath(rsrc)
            ntup = self.SRC_DST_NTUP(
                    src=src,
                    dst=dst)
            out.append(ntup)
        return out

    @property
    def path_ntups(self) -> list:
        """ List of named tuples
        """
        if self._path_ntups is None:
            self._path_ntups = self.mk_path_ntups()
        return self._path_ntups

    @property
    def to_copy_ntups(self) -> list:
        """ Returns the tuples from self.path_ntups which should be copied
        (i.e., do not exist in dst)
        """
        if self._to_copy_ntups is None:
            self._to_copy_ntups = []
            for tup in self.path_ntups:
                if tup.src.is_file() and not tup.dst.exists():
                    self._to_copy_ntups.append(tup)
        return self._to_copy_ntups


    def add_parents(self, root: pathlib.Path, paths: list) -> list:
        """ Returns a list with paths and their parents
        """
        # Get all parents
        out = []
        for pth in paths:
            rpth = pth.relative_to(root)
            parts = rpth.parts[:-1]
            for i, x in enumerate(parts):
                if i == 0:
                    this_dir = root.joinpath(x)
                else:
                    this_dir = this_dir.joinpath(x)
                if this_dir not in out:
                    out.append(this_dir)
            out.append(pth)
        return out


    def assert_dst_not_exist(self):
        """ Check if any destination file (not folder) in the path_ntups
        exists
        """
        invalid = []
        for tup in self.path_ntups:
            dst = tup.dst
            if not dst.exists():
                continue
            elif dst.is_file():
                invalid.append(dst)
        if len(invalid) > 0:
            if self.dst not in invalid:
                invalid.insert(0, self.dst)
            paths = self.add_parents(root=self.dst, paths=invalid)
            dst_tree = _pp.dirtree(
                    paths=paths,
                    root=self.dst,
                    )
            msg = ["The following destination files already exist:", 
                   dst_tree]
            raise Exception(_pp.fmt_msg(msg))

    # TODO: Return tuple of None if no files are to be copied
    def mk_dirtrees(
            self,
            new_files_only: bool = False,
            existing_only: bool = False,
            ) -> tuple:
        """ Returns a tuple with the src and dst dirtrees
        """
        arrows = {}
        dst_pths = [self.dst]
        src_pths = []
        for tup in self.path_ntups:
            src, dst = tup.src, tup.dst
            if dst == self.dst:
                continue
            if (
                    new_files_only is True 
                    and dst.exists()
                    and dst.is_file()
                    ):
                continue
            if existing_only is True and not dst.exists():
                continue
            dst_pths.append(dst)
            src_pths.append(src)

        dst_pths = self.add_parents(paths=dst_pths, root=self.dst)
        dst_tree = _pp.dirtree(
                paths=dst_pths,
                root=self.dst,
                )
        src_pths = self.add_parents(paths=src_pths, root=self.src)
        if len(src_pths) == 0:
            src_pths.append(self.src)
        src_tree = _pp.dirtree(
                paths=src_pths,
                root=self.src,
                )
        return src_tree, dst_tree

    def copytree(self):
        """
        """
        if self.raise_if_exists is True:
            self.assert_dst_not_exist()
        for tup in self.to_copy_ntups:
            copyfile(src=tup.src, dst=tup.dst)


def copytree(
        src: str | pathlib.Path, 
        dst: str | pathlib.Path,
        exclude: set[str] | None = None,
        include: set[str] | None = None,
        filter_files: Callable | None = None,
        filter_dirs: Callable | None = None,
        dirs_only: bool = False,
        files_only: bool = False,
        raise_if_exists: bool = False,
        dry_run: bool = False,
        ):
    """
    """
    kargs = {
            'src': src,
            'dst': dst,
            'exclude': exclude,
            'include': include,
            'filter_files': filter_files,
            'filter_dirs': filter_dirs,
            'dirs_only': dirs_only,
            'files_only': files_only,
            'dry_run': dry_run,
            'raise_if_exists': raise_if_exists,
        }
    c = CopyTree(**kargs)
    if dry_run:
        src_tree, dst_tree = c.mk_dirtrees(new_files_only=True)
        print("Copying files (DRY RUN):")
        print("From:")
        print(src_tree)
        print("To:")
        print(dst_tree)
    else:
        c.copytree()













