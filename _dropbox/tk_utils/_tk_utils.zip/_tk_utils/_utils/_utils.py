""" General utils

         
"""
from __future__ import annotations

import datetime as dt
import math
import pathlib
import os
from collections import namedtuple

from ._converters import (
        as_path,
        )

__all__ = [
        'as_path',
        'file_size',
        'bytes2human',
        'fmt_elapsed',
        ]


def bytes2human(
        num: int,
        add_space: bool = True,
        ):
    """ Auxiliary function to convert the number of bytes `num` 
    to something easier to read

    Parameters
    ----------
    num: int
        Bytes

    Examples
    --------

    >>> chk = bytes2human(1024**4)
    >>> print(chk)
    1.0 TB
    >>> chk = bytes2human(1024**2, add_space=False)
    >>> print(chk)
    1.0MB

    """
    spc = ' ' if add_space else ''
    for x in ['bytes','KB','MB','GB','TB']:
        if num < 1024.0:
            return f"{num:3.1f}{spc}{x}"
        num /= 1024.0


def file_size(
        pth: str | pathlib.Path,
        as_human: bool = True,
        ) -> int | str:
    """ Returns the size of a file (human or bytes)

    Parameters
    ----------
    pth: path-like
        Location of the file

    as_human: bool, default True
        Returns file size as a human-readable string

    """
    bytes_ = os.stat(pth).st_size
    if as_human:
        return bytes2human(bytes_)
    else:
        return bytes_


def mk_elapsed_ntup(elapsed):
    """ Returns a named tuple with elapsed time
    """
    days = elapsed.days
    _remaining_secs = elapsed.seconds
    hours = math.floor(_remaining_secs/ (60. * 60))
    _secs_in_hours = hours * (60 * 60)
    _remaining_secs = _remaining_secs - _secs_in_hours
    mins = math.floor(_remaining_secs/60.)

    secs = _remaining_secs - (mins * 60)
    ms = elapsed.microseconds

    ntup = namedtuple('elapsed', [
        'days',
        'hours',
        'mins',
        'secs',
        'ms',
        ])

    return ntup(days, hours, mins, secs, ms) 


def fmt_elapsed(elapsed):
    """ Object representing elapsed time

    Parameters
    ----------
    elapsed: datetime.timedelta

    """
    ntup = mk_elapsed_ntup(elapsed)

    output = []
    # Start showing from the first non-zero 
    skip = True
    for attr in ['days', 'hours', 'mins']:
        v = getattr(ntup, attr)
        if v > 0:
            skip = False
        if skip is False:
            output.append(f"{v} {attr}")
    # fix secs
    secs = ntup.secs + ntup.ms/1000000.0

    if secs > 60:
        secs_str = f"{secs:.2f}"
    else:
        secs_str = f"{secs:.6f}"
    output.append(f"{secs_str} secs")
    return ', '.join(output)

