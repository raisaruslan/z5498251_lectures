""" Converters

         
"""
from __future__ import annotations

import pathlib

from .._typing import (
        Sequence,
        Set,
        )




def as_path(pth: str | pathlib.Path) -> pathlib.Path:
    """ Ensure `pth` is a pathlib.Path instance

    Parameters
    ----------
    pth: str, pathlib.Path
        Path 


    Examples
    --------

    >>> import pathlib
    >>> pth = as_path('/home')
    >>> chk = isinstance(pth, pathlib.Path)
    >>> print(chk)
    True

        
    """
    return pth if isinstance(pth, pathlib.Path) else pathlib.Path(pth)







